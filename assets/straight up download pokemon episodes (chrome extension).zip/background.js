chrome.runtime.onMessage.addListener((message, sender, respond)=>{ // only message will be download message
	const idMatch = message.url.match(/\?id=([0-9a-f]+)/); // get the ID portion of the URL (don't use params, the whole thing is part of hash)
	if (idMatch===null) throw "ID not found in URL";
	const id = idMatch[1]; // capturing group 1 of the regex
	console.log("Got id "+id);
	new Promise((resolve,reject)=>{ // gonna make some asynchronous XMLHttpRequests
		let request = new XMLHttpRequest();
		request.onload = ()=>resolve(request.responseText);
		request.onerror = reject;
		request.open("GET", "https://production-ps.lvp.llnw.net/r/PlaylistService/media/"+id+"/getMobilePlaylistByMediaId"); // fixed link with JSON data for episode download and subtitle download
		request.send();
	})
	.then(responseText=>JSON.parse(responseText).mediaList[0]) // parse response text as JSON and get the video metadata
	.then(metadata=>{
		let downloadPromises = [];
		for (const source of metadata.mobileUrls) { // iterate through media sources (video & subtitles)
			if (source.targetMediaPlatform==="MobileH264") { // if source is the video, download it
				console.log("Found video at path "+source.mobileUrl)
				const videoDownload = new Promise((resolve,reject)=>chrome.downloads.download({url: source.mobileUrl},resolve));
				downloadPromises.push(videoDownload);
			}
			if (source.targetMediaPlatform==="HttpLiveStreaming"&&message.subtitles) { // if source is the m3u8 file linking to subtitles, and user wants subtitles
				console.log("Requesting m3u8 file "+source.mobileUrl+" to check for subtitles")
				const subtitleDownload = new Promise((resolve,reject)=>{ // need to request the m3u8 file to find link to subtitles
					let request = new XMLHttpRequest();
					request.onload = ()=>resolve(request.responseText);
					request.onerror = reject;
					request.open("GET", source.mobileUrl);
					request.send();
				})
				.then(responseText=>responseText.match(/^#EXT-X-MEDIA:TYPE=SUBTITLES.+URI="([^"]+)"/m)[1]) // find subtitles path (yes this regex could fail if variation was introduced)
				.then(subtitlePathRelative=>new URL(subtitlePathRelative,source.mobileUrl)) // get absolute path to subtitle m3u8 file
				.then(subtitlePath=>{
					const language = subtitlePath.pathname.match(/([^/]+)\.m3u8/)[1]; // get language code
					const vttPath = new URL("chunkable_"+language+".vtt", subtitlePath.href).href; // get path to actual subtitle data in VTT form
					console.log("Found subtitles at path "+vttPath)
					chrome.downloads.download({url: vttPath, filename: metadata.title+"_subtitles.vtt"}, Promise.resolve); // download subtitle data, resolve
				});
				downloadPromises.push(subtitleDownload);
			}
		}
		return Promise.allSettled(downloadPromises);
	})
	.then(respond)
	.catch(respond);
})
