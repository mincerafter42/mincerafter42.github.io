document.getElementById("download").addEventListener("click",()=>chrome.runtime.sendMessage({
	url: document.getElementById("episodeURL").value, 
	subtitles: document.getElementById("subtitles").checked}
));
